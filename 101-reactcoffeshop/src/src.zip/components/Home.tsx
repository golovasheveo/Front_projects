import React from 'react';
import TopBar from "./TopBar";
import {coffeeMenu} from "../const/Menu";


const Home: React.FC = () => {
  
  return <React.Fragment>
      <TopBar headers={coffeeMenu}/>
      <h3>MENU</h3>
  </React.Fragment>
};

export default Home;