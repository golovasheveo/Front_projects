import React from 'react';
import {coffeeMenu} from "../const/Menu";
import TopBar from "./TopBar";



const Show: React.FC = () => {
  
  return <React.Fragment>
      <TopBar headers={coffeeMenu}/>
      <h3>SHOW</h3>
  </React.Fragment>
};

export default Show;