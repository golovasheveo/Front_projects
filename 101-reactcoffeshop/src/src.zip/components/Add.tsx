import React from 'react';
import TopBar from "./TopBar";
import {coffeeMenu} from "../const/Menu";



const Add: React.FC = () => {
  
  return <React.Fragment>
      <TopBar headers={coffeeMenu}/>
      <h3>ADD</h3>
  </React.Fragment>
};

export default Add;