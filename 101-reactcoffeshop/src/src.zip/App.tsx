import React from 'react';
import {HashRouter, Switch, Route, Redirect} from "react-router-dom";
import {coffeeMenu} from "./const/Menu";
import Home from "./components/Home";

function App() {

  return <HashRouter>
    <Redirect to={coffeeMenu[0].path}/>
      <Switch>
        {coffeeMenu.map(item=>
          <Route path={item.path} exact render={() => < item.comp />}/>
        )}
      </Switch>
    </HashRouter>
}

export default App;
