import React from 'react';
import './App.css';
import {HashRouter, Switch, Route, Redirect} from 'react-router-dom';
import {StateBar, Toolbar} from "./Toolbar";
import AComponent from "./AComponent";
import BComponent from "./BComponent";
import Dashboard from "./Dashboard";


export default function App() {
    return <React.Fragment>
        <HashRouter>
            <Toolbar links={[
                {path:'/Dashboard', label:'Dashboard'},
                {path:'/acomponent', label:'Acomponent'},
                {path:'/bcomponent', label: "Bcomponent"},
            ]}/>
            <Redirect to={'/Dashboard'}/>
            <Switch>
                <Route exact path={'/Dashboard'} render={() => <Dashboard color="green"/>}/>
                <Route exact path='/acomponent' component={AComponent}/>
                <Route exact path='/bcomponent' component={BComponent}/>
            </Switch>
        </HashRouter>
    </React.Fragment>
}
