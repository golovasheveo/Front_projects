import React, {Component} from "react";
export default class BComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            background: "Blue"
        }
    }
    changeBackground(color) {
        this.setState(() => {return {background: color}} )
    }

    componentDidMount() {
        console.log("component Mount")
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        console.log("component Updated")

    }

    render() {
        return <React.Fragment>
            <div style={{background: this.state.background,  color: 'white'}}>
                BComponent
                {console.log("Run render BComponent")}
                <br/><br/>
                <button onClick={() => this.changeBackground("purple")}>BUTTON Purple</button>
                <button onClick={() => this.changeBackground("red")}>BUTTON Red</button>
                <button onClick={() => this.changeBackground(this.props.color)}>BUTTON Default</button>
            </div>
        </React.Fragment>
    }
}

