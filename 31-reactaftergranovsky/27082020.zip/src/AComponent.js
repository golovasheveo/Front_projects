import React, {Component} from "react";
export default class AComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            background: "Yellow"
        }
    }
    changeBackground(color) {
        this.setState(() => {return {background: color}} )
    }

    componentDidMount() {
        console.log("component Mount")
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        console.log("component Updated")

    }

    render() {
        {console.log("Run render AComponent")}

        return <React.Fragment>
            <div style={{background: this.state.background,  color: 'white'}}>
                AComponent
                <br/><br/>
                <button onClick={() => this.changeBackground("purple")}>BUTTON Purple</button>
                <button onClick={() => this.changeBackground("red")}>BUTTON Red</button>
                <button onClick={() => this.changeBackground(this.props.color)}>BUTTON Default</button>
            </div>
        </React.Fragment>
    }
}

