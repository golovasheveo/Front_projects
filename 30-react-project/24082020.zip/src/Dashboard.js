import React from 'react'

export const Dashboard = () => <label>Dashboard is working</label>
