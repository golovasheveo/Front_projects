import React from "react";
import {HashRouter, Switch, Route, Redirect} from 'react-router-dom'
import {Dashboard} from "./Dashdoard";
import {Clock} from "./Clock";
import Toolbar from "./Toolbar";


const App = () => {
    return <React.Fragment>
        <HashRouter>
            <Toolbar links={[{path: '/dashboard', label: 'Dashboard'},
                {path: '/clock', label: 'Clock'}]}/>
            <Redirect to={'/dashboard'}/>
            <Switch>
                <Route exact path={'/dashboard'} component={Dashboard}/>

                <Route exact path={'/clock'} render={ () => <Clock interval={1000}/>}/>

                {/*<Route exact path={'/clock'} component= {Clock} />}*/}


            </Switch>
        </HashRouter>
    </React.Fragment>
}
export default App;