import React from 'react';
import Row from "./Row";

export default function Matrix(props) {
    function getRows() {
        return props.numbers.map ( r => <Row row={r}/>)
    }
    return <div style={{"display": "flex",
    "flexDirection": "colum"}}>
        {getRows()}
    </div>
}