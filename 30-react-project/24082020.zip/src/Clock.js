import React from "react";
// export const Clock = (props) => <label >Clock is working with interval {props.interval || 1000} </label>

var i=0;

export class Clock extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            date: new Date()
        }
    }
    tick =() => {
        this.setState(() => {
            return {date: new Date()}
        } )
        console.log("Tick number", i++);
    }
    componentDidMount() {
        this.intervalId = setInterval(this.tick,
            this.props.interval || 1000)
            // 1000)
    }
    componentWillUnmount() {
        clearInterval(this.intervalId);
        console.log("Unmount");
    }
        render() {
        return <label> {this.state.date.toLocaleTimeString()}</label>
    }
}