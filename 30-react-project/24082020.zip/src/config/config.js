export const N_COLUMNS = 4;
export const N_ROWS = 4;
export const INTERVAL = 2000;