import {N_ROWS, N_COLUMNS, INTERVAL} from "../config/config";
import {getRandomNumber} from "../utils/random";

export default class TransformNumbers {
    constructor(numbers) {
        this.numbers = numbers;
    }

    getNumbers() {
        for (let i = 0; i < this.numbers.length; i++) {
            for (let j = 0; j < this.numbers[i].length; j++) {
                // this.numbers[i][j] = getRandomNumber(0, 1);
                this.numbers[i][j] = this.scanForLive(i, j);

            }
        }
        return this.numbers;
    }

    scanForLive(iRow, jColumn) {
        console.log('EnterParam', iRow, jColumn, this.numbers);
        let countLiveCells = 0;
        const rawL = N_ROWS;
        const colL = N_COLUMNS;
        let iCurr = (iRow - 1);
        let jCur = (jColumn - 1);
        for (let i = 0; i < 3; i++) {
            if(iCurr < 0 || iCurr >= rawL){
                iCurr++;
                break;
            }
            for (let k = 0; k < 3; k++) {
                if(jCur < 0 || jCur >= colL){
                    jCur++;
                    break;
                }
                if(this.numbers[iCurr][jCur] === 1){
                    countLiveCells++
                }
                jCur++;
            }
            jCur = (jColumn - 1);
            iCurr++;
        }
        console.log("countLiveCells", countLiveCells);
        if (countLiveCells > 2){
            return 1;
        }else
            return 0;
    }

}