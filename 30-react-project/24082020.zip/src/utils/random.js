export function getRandomNumber(min, max) {
    if (min > max) {
        [min, max] = [max, min];
    }
    return min + Math.round(Math.random() * (max - min))
}

export function getRandomMatrix(nColumns, nRows, min, max) {
    // const numbers = new Array();
    // for (let i = 0; i < nRows; i++) {
    //     numbers.push(new Array())
    //     for (let j = 0; j < nColumns; j++) {
    //         numbers[i].push(getRandomNumber(min, max));
    //     }
    // }

    // const numbers = new Array();
    // for (let i = 0; i < nRows; i++) {
    //     numbers.push(new Array())
    //     for (let j = 0; j < nColumns; j++) {
    //         if ((j=1)||(j=2))
    //             numbers[i].push("1");
    //         else numbers[i].push("0")
    //     }
    // }

    const numbers = new Array();
    numbers.push(new Array(0,1,0,0));
    numbers.push(new Array(0,1,0,0));
    numbers.push(new Array(0,1,0,0));
    numbers.push(new Array(0,0,0,0));
    console.log('HELLO PIPIC', numbers);

    return numbers;

}