import React from "react";
import Redirect from "react-router-dom/es/Redirect";
// props array of objects {path:string, label:string}


export default class Toolbar extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            path: ''
        }
    }
    handleButton(path) {
        this.setState(()=> {return {path:path}});
    }
    render() {
        const buttons = this.props.links.map(l =>
            <button key={l.label} onClick={this.handleButton.bind(this, l.path)}>{l.label}</button>)
        return <React.Fragment>
            {buttons} <br/>  <br/>
            {this.state.path ?  <Redirect to={this.state.path}/> : null}

        </React.Fragment>
    }
}