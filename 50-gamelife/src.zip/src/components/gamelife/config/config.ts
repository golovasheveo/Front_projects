export const N_COLUMNS = 50;
export const N_ROWS = 50;
export const INTERVAL = 100;