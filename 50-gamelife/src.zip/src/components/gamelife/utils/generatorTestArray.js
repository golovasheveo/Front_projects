export function getLessThenTwoArDie() {

    var numbers = [
        [0,0,1,0],
        [1,0,0,1],
        [0,0,0,0],
        [1,0,0,1]
    ];
    return numbers;

}
export function getLessThenTwoArDie2() {

    var numbers = [
        [1,0,1,0],
        [0,0,0,0],
        [0,0,0,0],
        [1,0,1,0]
    ];
    return numbers;

}

export function getTwoThreeLives() {

    var numbers = [
        [1,0,0,0],
        [0,1,0,0],
        [0,0,1,0],
        [0,0,0,0]
    ];
    return numbers;

}
export function getFourDies() {

    var numbers = [
        [0,1,0,0],
        [1,1,1,0],
        [0,1,0,0],
        [0,0,0,0]
    ];
    return numbers;

}
export function getDeadThreeLives() {

    var numbers = [
        [0,1,0,0],
        [1,0,1,0],
        [0,0,0,0],
        [0,0,0,0]
    ];
    return numbers;

}
    [ 0, 1, 0, 0 ],
    [ 0, 1, 0, 0 ],
    [ 0, 0, 0, 0 ],
    [ 0, 0, 0, 0 ]

