import React from 'react';
import Toolbar from "./Toolbar";

const Settings = () => {
    
    return <React.Fragment>
        <Toolbar />
        <label>Settings</label>



    </React.Fragment>
};

export default Settings;